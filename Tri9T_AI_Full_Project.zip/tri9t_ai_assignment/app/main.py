from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4
import hashlib, difflib, json, os, shutil, tempfile
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.database import Base, engine, get_db
from app.models import Document, DocumentVersion, DocumentNode, Selection, SelectionItem, GenerationRecord
from app.schemas import IngestResponse, NodeOut, SelectionCreate, GenerateRequest, GenerationOut, TestCase
from app.parser import parse_pdf, sha256_text, normalize
from app.generator import generate_cases
from app.store import put_record, get_record

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title="Tri9T AI — CT-200 QA Traceability API", version="1.0.0", lifespan=lifespan)

def node_out(node: DocumentNode) -> dict:
    return {k: getattr(node, k) for k in ["id","version_id","logical_key","parent_id","heading","level","body_text","content_hash","node_type","page_number"]}

def make_tree(nodes: list[DocumentNode]) -> list[dict]:
    by_id = {n.id: {**node_out(n), "children": []} for n in nodes}
    roots = []
    for n in nodes:
        item = by_id[n.id]
        if n.parent_id in by_id:
            by_id[n.parent_id]["children"].append(item)
        else:
            roots.append(item)
    return roots

def _logical_key(path_titles: list[str], heading: str, body: str) -> str:
    # Path + normalized heading avoids collapsing duplicate headings under different parents.
    return sha256_text(" > ".join(path_titles) + "|" + normalize(heading).casefold())[:64]

def _latest_version(db: Session, doc: Document) -> DocumentVersion | None:
    return db.scalar(select(DocumentVersion).where(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_number.desc()))

def _find_document(db: Session, name: str) -> Document:
    doc = db.scalar(select(Document).where(Document.name == name))
    if not doc:
        raise HTTPException(404, f"Document '{name}' not found")
    return doc

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/documents/ingest", response_model=IngestResponse)
async def ingest_document(file: UploadFile = File(...), document_name: str = Query("CT-200"), db: Session = Depends(get_db)):
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Upload a PDF file")
    raw = await file.read()
    if not raw:
        raise HTTPException(400, "Uploaded PDF is empty")
    sha = hashlib.sha256(raw).hexdigest()
    doc = db.scalar(select(Document).where(Document.name == document_name))
    if not doc:
        doc = Document(name=document_name)
        db.add(doc); db.flush()
    existing = db.scalar(select(DocumentVersion).where(DocumentVersion.document_id == doc.id, DocumentVersion.source_sha256 == sha))
    if existing:
        count = db.scalar(select(DocumentNode).where(DocumentNode.version_id == existing.id).count()) if False else len(existing.nodes)
        return IngestResponse(document_id=doc.id, document_name=doc.name, version_id=existing.id, version_number=existing.version_number, node_count=count, source_sha256=sha, warnings=["This exact PDF has already been ingested; no duplicate version created."])
    temp_path = None
    try:
        fd, temp_path = tempfile.mkstemp(suffix=".pdf")
        with os.fdopen(fd, "wb") as f: f.write(raw)
        parsed, warnings = parse_pdf(temp_path)
    except Exception as exc:
        raise HTTPException(422, f"PDF parsing failed: {exc}")
    finally:
        if temp_path and os.path.exists(temp_path): os.unlink(temp_path)
    if not parsed:
        raise HTTPException(422, "No nodes extracted from PDF; OCR or parser support may be required.")
    latest = _latest_version(db, doc)
    version_number = 1 if latest is None else latest.version_number + 1
    version = DocumentVersion(document_id=doc.id, version_number=version_number, source_filename=file.filename, source_sha256=sha)
    db.add(version); db.flush()
    # Map parsed parent indexes to persistent IDs and logical path keys.
    ids, keys, paths = [], [], []
    previous_by_key = {}
    if latest:
        previous_by_key = {n.logical_key: n for n in latest.nodes}
    created = []
    for i, p in enumerate(parsed):
        parent_id = ids[p.parent_index] if p.parent_index is not None else None
        parent_path = paths[p.parent_index] if p.parent_index is not None else []
        logical_key = _logical_key(parent_path, p.heading, p.body_text)
        # Reuse logical ID only when matching a node in the immediately prior version.
        old = previous_by_key.get(logical_key)
        node_id = old.id if old else str(uuid4())
        ids.append(node_id); keys.append(logical_key); paths.append(parent_path + [p.heading])
        node = DocumentNode(id=node_id, version_id=version.id, logical_key=logical_key, parent_id=parent_id,
            heading=p.heading, level=p.level, body_text=p.body_text, content_hash=sha256_text(normalize(p.heading) + "\n" + normalize(p.body_text)),
            node_type=p.node_type, page_number=p.page_number)
        db.add(node); created.append(node)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(500, "Could not persist parsed document; check duplicate logical-node IDs and database constraints.")
    return IngestResponse(document_id=doc.id, document_name=doc.name, version_id=version.id, version_number=version_number, node_count=len(created), source_sha256=sha, warnings=warnings)

@app.get("/documents")
def list_documents(db: Session = Depends(get_db)):
    docs = db.scalars(select(Document).order_by(Document.name)).all()
    return [{"id": d.id, "name": d.name, "latest_version": (_latest_version(db,d).version_number if _latest_version(db,d) else None)} for d in docs]

@app.get("/documents/{document_name}/sections")
def top_sections(document_name: str, version: int | None = None, db: Session = Depends(get_db)):
    doc = _find_document(db, document_name)
    v = _latest_version(db, doc) if version is None else db.scalar(select(DocumentVersion).where(DocumentVersion.document_id==doc.id, DocumentVersion.version_number==version))
    if not v: raise HTTPException(404, "Document version not found")
    nodes = db.scalars(select(DocumentNode).where(DocumentNode.version_id==v.id).order_by(DocumentNode.page_number, DocumentNode.level)).all()
    roots = [n for n in nodes if n.parent_id is None]
    return {"document": doc.name, "version": v.version_number, "sections": [node_out(n) for n in roots]}

@app.get("/nodes/{node_id}")
def get_node(node_id: str, version_id: int | None = None, db: Session = Depends(get_db)):
    node = db.get(DocumentNode, node_id)
    if not node: raise HTTPException(404, "Node not found")
    if version_id is not None:
        node = db.scalar(select(DocumentNode).where(DocumentNode.id==node_id, DocumentNode.version_id==version_id))
        if not node: raise HTTPException(404, "Node not found in that version")
    nodes = db.scalars(select(DocumentNode).where(DocumentNode.version_id==node.version_id)).all()
    tree = make_tree(nodes)
    def find(items):
        for item in items:
            if item["id"] == node.id: return item
            found = find(item["children"])
            if found: return found
        return None
    return find(tree)

@app.get("/search")
def search_nodes(q: str = Query(min_length=1), document_name: str = "CT-200", version: int | None = None, db: Session = Depends(get_db)):
    doc = _find_document(db, document_name)
    v = _latest_version(db, doc) if version is None else db.scalar(select(DocumentVersion).where(DocumentVersion.document_id==doc.id, DocumentVersion.version_number==version))
    if not v: raise HTTPException(404, "Document version not found")
    query = f"%{q}%"
    nodes = db.scalars(select(DocumentNode).where(DocumentNode.version_id==v.id, (DocumentNode.heading.ilike(query) | DocumentNode.body_text.ilike(query)))).all()
    return {"document": doc.name, "version": v.version_number, "query": q, "results": [node_out(n) for n in nodes]}

@app.get("/nodes/{node_id}/changes")
def node_changes(node_id: str, db: Session = Depends(get_db)):
    node = db.get(DocumentNode, node_id)
    if not node: raise HTTPException(404, "Node not found")
    version = db.get(DocumentVersion, node.version_id)
    doc = db.get(Document, version.document_id)
    latest = _latest_version(db, doc)
    matches = db.scalars(select(DocumentNode).where(DocumentNode.version_id==latest.id, DocumentNode.logical_key==node.logical_key)).all()
    current = matches[0] if matches else None
    if current is None:
        return {"node_id": node.id, "source_version": version.version_number, "latest_version": latest.version_number, "changed": True, "status": "removed_or_moved", "summary": "No node with the same path-and-heading logical key exists in the latest version."}
    changed = node.content_hash != current.content_hash
    diff = list(difflib.unified_diff(node.body_text.splitlines(), current.body_text.splitlines(), fromfile=f"v{version.version_number}", tofile=f"v{latest.version_number}", lineterm="")) if changed else []
    return {"node_id": node.id, "logical_key": node.logical_key, "source_version": version.version_number, "latest_version": latest.version_number, "changed": changed, "status": "changed" if changed else "unchanged", "summary": "\n".join(diff[:20]) if diff else "Content hash matches.", "old_hash": node.content_hash, "current_hash": current.content_hash}

@app.post("/selections")
def create_selection(payload: SelectionCreate, db: Session = Depends(get_db)):
    nodes = []
    for node_id in payload.node_ids:
        node = db.get(DocumentNode, node_id)
        if not node: raise HTTPException(404, f"Node '{node_id}' not found")
        if payload.version_id is not None and node.version_id != payload.version_id:
            raise HTTPException(400, f"Node '{node_id}' does not belong to version_id {payload.version_id}")
        nodes.append(node)
    versions = {n.version_id for n in nodes}
    if len(versions) != 1:
        raise HTTPException(400, "All selected nodes must belong to the same document version")
    selection = Selection(id=str(uuid4()), name=payload.name)
    db.add(selection); db.flush()
    for node in nodes:
        db.add(SelectionItem(selection_id=selection.id, node_id=node.id, version_id=node.version_id,
            node_content_hash=node.content_hash, node_heading_snapshot=node.heading,
            node_text_snapshot=(node.heading + "\n" + node.body_text).strip()))
    db.commit()
    return {"id": selection.id, "name": selection.name, "version_id": nodes[0].version_id, "items": [{"node_id": n.id, "version_id": n.version_id, "content_hash": n.content_hash} for n in nodes]}

@app.get("/selections/{selection_id}")
def get_selection(selection_id: str, db: Session = Depends(get_db)):
    selection = db.get(Selection, selection_id)
    if not selection: raise HTTPException(404, "Selection not found")
    return {"id": selection.id, "name": selection.name, "items": [{"node_id": x.node_id, "version_id": x.version_id, "heading": x.node_heading_snapshot, "text": x.node_text_snapshot, "content_hash": x.node_content_hash} for x in selection.items]}

def _staleness(db: Session, manifest: list[dict]) -> tuple[bool, list[str]]:
    reasons = []
    for item in manifest:
        old = db.get(DocumentNode, item["node_id"])
        if not old:
            reasons.append(f"Source node {item['node_id']} is missing from the database.")
            continue
        version = db.get(DocumentVersion, old.version_id)
        doc = db.get(Document, version.document_id)
        latest_v = _latest_version(db, doc)
        current = db.scalar(select(DocumentNode).where(DocumentNode.version_id==latest_v.id, DocumentNode.logical_key==item["logical_key"]))
        if not current:
            reasons.append(f"Source section '{item['heading']}' was removed, moved, or could not be matched in latest version {latest_v.version_number}.")
        elif current.content_hash != item["content_hash"]:
            reasons.append(f"Source section '{item['heading']}' changed between version {version.version_number} and {latest_v.version_number}.")
    return bool(reasons), reasons

@app.post("/generate", response_model=GenerationOut)
def generate(payload: GenerateRequest, db: Session = Depends(get_db)):
    selection = db.get(Selection, payload.selection_id)
    if not selection: raise HTTPException(404, "Selection not found")
    if not payload.force_new:
        existing = db.scalars(select(GenerationRecord).where(GenerationRecord.selection_id==selection.id).order_by(GenerationRecord.created_at.desc())).first()
        if existing:
            record = get_record(existing.store_key)
            if record:
                stale, reasons = _staleness(db, json.loads(existing.source_manifest))
                return GenerationOut(generation_id=existing.id, selection_id=selection.id, provider=existing.provider, status="reused-existing", stale=stale, stale_reasons=reasons, test_cases=[TestCase.model_validate(c) for c in record["test_cases"]], warnings=["Reused prior generation for this selection. Set force_new=true to generate again."])
    items = selection.items
    sections = [{"heading": x.node_heading_snapshot, "text": x.node_text_snapshot, "node_id": x.node_id, "version_id": x.version_id} for x in items]
    cases, provider, warnings = generate_cases(sections)
    generation_id = str(uuid4())
    manifest = []
    for item in items:
        node = db.get(DocumentNode, item.node_id)
        manifest.append({"node_id": item.node_id, "version_id": item.version_id, "content_hash": item.node_content_hash, "logical_key": node.logical_key if node else "", "heading": item.node_heading_snapshot})
    store_record = {"generation_id": generation_id, "selection_id": selection.id, "created_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(), "provider": provider, "test_cases": cases, "source_manifest": manifest}
    put_record(generation_id, store_record)
    db.add(GenerationRecord(id=generation_id, selection_id=selection.id, provider=provider, status="success", store_key=generation_id, source_manifest=json.dumps(manifest)))
    db.commit()
    stale, reasons = _staleness(db, manifest)
    return GenerationOut(generation_id=generation_id, selection_id=selection.id, provider=provider, status="created", stale=stale, stale_reasons=reasons, test_cases=[TestCase.model_validate(c) for c in cases], warnings=warnings)

def _generation_out(rec: GenerationRecord, db: Session):
    data = get_record(rec.store_key)
    if not data: raise HTTPException(500, "Generation metadata exists but JSON payload is missing.")
    manifest = json.loads(rec.source_manifest)
    stale, reasons = _staleness(db, manifest)
    return {"generation_id": rec.id, "selection_id": rec.selection_id, "provider": rec.provider, "status": rec.status, "stale": stale, "stale_reasons": reasons, "test_cases": data["test_cases"], "warnings": []}

@app.get("/generations/{generation_id}", response_model=GenerationOut)
def get_generation(generation_id: str, db: Session = Depends(get_db)):
    rec = db.get(GenerationRecord, generation_id)
    if not rec: raise HTTPException(404, "Generation not found")
    return _generation_out(rec, db)

@app.get("/generations")
def list_generations(selection_id: str | None = None, node_id: str | None = None, db: Session = Depends(get_db)):
    stmt = select(GenerationRecord)
    if selection_id: stmt = stmt.where(GenerationRecord.selection_id==selection_id)
    records = db.scalars(stmt.order_by(GenerationRecord.created_at.desc())).all()
    out = []
    for rec in records:
        manifest = json.loads(rec.source_manifest)
        if node_id and not any(x["node_id"] == node_id for x in manifest):
            continue
        out.append(_generation_out(rec, db))
    return {"count": len(out), "generations": out}
