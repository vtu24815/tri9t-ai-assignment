"""Simple JSON store for generated LLM output, separate from relational metadata."""
import json, os, tempfile
from pathlib import Path
from threading import RLock
from app.config import settings

_lock = RLock()

def _path() -> Path:
    p = Path(settings.generated_store_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def read_all() -> dict:
    p = _path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        # Corrupt store should fail visibly, not be overwritten silently.
        raise RuntimeError(f"Generated-output store is unreadable: {p}")

def get_record(key: str):
    with _lock:
        return read_all().get(key)

def put_record(key: str, value: dict):
    with _lock:
        p = _path()
        data = read_all()
        data[key] = value
        fd, tmp_name = tempfile.mkstemp(dir=str(p.parent), prefix=".tmp-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_name, p)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
