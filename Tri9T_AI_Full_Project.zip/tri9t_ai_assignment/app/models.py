from datetime import datetime, timezone
from sqlalchemy import String, Integer, Text, DateTime, ForeignKey, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Document(Base):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    versions: Mapped[list["DocumentVersion"]] = relationship(back_populates="document", cascade="all, delete-orphan")

class DocumentVersion(Base):
    __tablename__ = "document_versions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"), index=True)
    version_number: Mapped[int] = mapped_column(Integer)
    source_filename: Mapped[str] = mapped_column(String(255))
    source_sha256: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    document: Mapped["Document"] = relationship(back_populates="versions")
    nodes: Mapped[list["DocumentNode"]] = relationship(back_populates="version", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("document_id", "version_number", name="uq_document_version"),)

class DocumentNode(Base):
    __tablename__ = "document_nodes"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"), index=True)
    logical_key: Mapped[str] = mapped_column(String(64), index=True)
    parent_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    heading: Mapped[str] = mapped_column(Text, default="")
    level: Mapped[int] = mapped_column(Integer, default=1)
    body_text: Mapped[str] = mapped_column(Text, default="")
    content_hash: Mapped[str] = mapped_column(String(64), index=True)
    node_type: Mapped[str] = mapped_column(String(30), default="section")
    page_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    version: Mapped["DocumentVersion"] = relationship(back_populates="nodes")

class Selection(Base):
    __tablename__ = "selections"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    items: Mapped[list["SelectionItem"]] = relationship(back_populates="selection", cascade="all, delete-orphan")

class SelectionItem(Base):
    __tablename__ = "selection_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    selection_id: Mapped[str] = mapped_column(ForeignKey("selections.id"), index=True)
    node_id: Mapped[str] = mapped_column(ForeignKey("document_nodes.id"))
    version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"))
    node_content_hash: Mapped[str] = mapped_column(String(64))
    node_heading_snapshot: Mapped[str] = mapped_column(Text)
    node_text_snapshot: Mapped[str] = mapped_column(Text)
    selection: Mapped["Selection"] = relationship(back_populates="items")

class GenerationRecord(Base):
    __tablename__ = "generation_records"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    selection_id: Mapped[str] = mapped_column(ForeignKey("selections.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    provider: Mapped[str] = mapped_column(String(50), default="none")
    status: Mapped[str] = mapped_column(String(30), default="success")
    store_key: Mapped[str] = mapped_column(String(36), unique=True)
    source_manifest: Mapped[str] = mapped_column(Text)
    selection: Mapped["Selection"] = relationship()
