import json, re
from typing import Any
import httpx
from app.config import settings
from app.schemas import TestCase

SYSTEM_PROMPT = """You are a medical-device QA test design assistant. Use only the supplied source text.
Return JSON with a top-level key test_cases containing 3 to 5 objects. Each object must have:
title, objective, preconditions (array), steps (non-empty array), expected_result,
requirement_trace (array of exact source heading labels), and risk (low|medium|high).
Do not invent numerical limits or requirements. If source is ambiguous, state that in the test
objective or expected result and flag it for human review. Output JSON only."""

def fallback_cases(sections: list[dict]) -> list[dict]:
    """Deterministic fallback for local demos; not a substitute for real LLM generation."""
    out = []
    for i, section in enumerate(sections[:3], start=1):
        heading = section["heading"] or "Selected requirement"
        body = section["text"].strip() or "No body text was extracted; review the source section."
        out.append({
            "title": f"Verify requirement: {heading[:140]}",
            "objective": f"Check that the device behavior described in '{heading}' is implemented as documented.",
            "preconditions": ["Use an approved test setup and the exact document version recorded in the selection."],
            "steps": [
                f"Review the source requirement: {body[:500]}",
                "Set up the device and test environment according to the approved procedure.",
                "Execute the behavior described by the selected requirement and record observations."
            ],
            "expected_result": "Observed behavior matches the selected source text; any unspecified acceptance criterion is escalated for clarification.",
            "requirement_trace": [heading],
            "risk": "medium"
        })
    while len(out) < 3:
        heading = sections[0]["heading"] if sections else "Selected document content"
        out.append({
            "title": f"Review traceability and coverage {len(out)+1}",
            "objective": "Verify that this generated test idea remains linked to its exact source version.",
            "preconditions": ["A saved, version-pinned selection exists."],
            "steps": ["Retrieve the selected node and version.", "Compare the stored source snapshot with the current version."],
            "expected_result": "The source version and content hash are available and any changed content is reported as potentially stale.",
            "requirement_trace": [heading],
            "risk": "low"
        })
    return out[:5]

def _extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end+1])
        raise ValueError("LLM did not return valid JSON")

def _validate_cases(payload: Any) -> list[dict]:
    if not isinstance(payload, dict) or not isinstance(payload.get("test_cases"), list):
        raise ValueError("LLM response must contain a test_cases array")
    raw = payload["test_cases"]
    if not 3 <= len(raw) <= 5:
        raise ValueError("LLM must return 3 to 5 test cases")
    cases = [TestCase.model_validate(x).model_dump() for x in raw]
    for case in cases:
        if case["risk"] not in {"low", "medium", "high"}:
            raise ValueError("risk must be low, medium, or high")
    return cases

def generate_cases(sections: list[dict]) -> tuple[list[dict], str, list[str]]:
    provider = (settings.llm_provider or "none").lower()
    warnings = []
    if provider == "openai-compatible" and settings.llm_api_key and settings.llm_base_url and settings.llm_model:
        user_content = json.dumps(sections, ensure_ascii=False)
        payload = {"model": settings.llm_model, "temperature": 0.1, "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": "Source sections (JSON):\n" + user_content}
        ], "response_format": {"type": "json_object"}}
        last_error = None
        for attempt in range(2):
            try:
                with httpx.Client(timeout=45) as client:
                    response = client.post(
                        settings.llm_base_url.rstrip("/") + "/chat/completions",
                        headers={"Authorization": f"Bearer {settings.llm_api_key}", "Content-Type": "application/json"},
                        json=payload
                    )
                    response.raise_for_status()
                    content = response.json()["choices"][0]["message"]["content"]
                return _validate_cases(_extract_json(content)), provider, warnings
            except Exception as exc:
                last_error = str(exc)
                warnings.append(f"LLM attempt {attempt+1} failed validation or request: {last_error[:240]}")
        warnings.append("Used deterministic local fallback after LLM failure.")
        return fallback_cases(sections), "local-fallback", warnings
    warnings.append("LLM provider is not configured; generated deterministic local examples. Configure .env for real LLM output.")
    return fallback_cases(sections), "local-fallback", warnings
