"""CT-200-focused PDF extraction. It deliberately flags uncertain structure.

Uses PyMuPDF text blocks when text is available. For scanned pages, OCR can be added
by installing Tesseract and wiring it into extract_pdf(); this implementation emits a
clear warning instead of silently pretending scanned pages were parsed.
"""
from dataclasses import dataclass, field
import hashlib
import re
import fitz

@dataclass
class ParsedNode:
    heading: str
    level: int
    body_text: str = ""
    parent_index: int | None = None
    node_type: str = "section"
    page_number: int | None = None
    children: list[int] = field(default_factory=list)

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()

def _heading_level(text: str) -> int | None:
    text = normalize(text)
    # Explicit numbered heading patterns are stronger than typography heuristics.
    m = re.match(r"^(\d+(?:\.\d+){0,5})[.)]?\s+\S", text)
    if m:
        return min(m.group(1).count(".") + 1, 6)
    if len(text) <= 110 and text.isupper() and re.search(r"[A-Z]", text):
        return 1
    if len(text) <= 100 and text.istitle() and not text.endswith((".", ";", ",")):
        return 2
    return None

def parse_pdf(path: str) -> tuple[list[ParsedNode], list[str]]:
    doc = fitz.open(path)
    nodes: list[ParsedNode] = []
    stack: list[int] = []
    warnings: list[str] = []
    for page_idx, page in enumerate(doc, start=1):
        blocks = page.get_text("dict").get("blocks", [])
        page_lines = []
        for block in blocks:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                spans = line.get("spans", [])
                txt = normalize("".join(span.get("text", "") for span in spans))
                if not txt:
                    continue
                size = max((span.get("size", 0) for span in spans), default=0)
                page_lines.append((txt, size))
        if not page_lines:
            warnings.append(f"Page {page_idx} has no extractable text; OCR is not configured.")
            continue
        sizes = sorted(size for _, size in page_lines)
        median_size = sizes[len(sizes)//2]
        for txt, size in page_lines:
            # Ignore common page-number-only lines; retain all other content.
            if re.fullmatch(r"(?:page\s+)?\d+(?:\s+of\s+\d+)?", txt, re.I):
                continue
            explicit = _heading_level(txt)
            typographic = size >= median_size * 1.22 and len(txt) <= 120
            is_heading = explicit is not None or typographic
            if is_heading:
                level = explicit if explicit is not None else (1 if size >= median_size * 1.55 else 2)
                # Avoid promoting obvious sentence fragments based only on font size.
                if explicit is None and txt.endswith((".", ",", ";")):
                    is_heading = False
            if is_heading:
                while stack and nodes[stack[-1]].level >= level:
                    stack.pop()
                parent = stack[-1] if stack else None
                node = ParsedNode(heading=txt, level=level, parent_index=parent, node_type="section", page_number=page_idx)
                nodes.append(node)
                idx = len(nodes)-1
                if parent is not None:
                    nodes[parent].children.append(idx)
                stack.append(idx)
            else:
                if not stack:
                    nodes.append(ParsedNode(heading="Document content", level=1, body_text=txt, page_number=page_idx, node_type="content"))
                    stack.append(len(nodes)-1)
                else:
                    target = nodes[stack[-1]]
                    target.body_text = (target.body_text + "\n" + txt).strip()
    doc.close()
    if not nodes:
        warnings.append("No document structure extracted. The PDF may be image-only or unsupported.")
    return nodes, warnings
