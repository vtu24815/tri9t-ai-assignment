from pydantic import BaseModel, Field, ConfigDict
from typing import Any

class IngestResponse(BaseModel):
    document_id: int
    document_name: str
    version_id: int
    version_number: int
    node_count: int
    source_sha256: str
    warnings: list[str] = []

class NodeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    version_id: int
    logical_key: str
    parent_id: str | None
    heading: str
    level: int
    body_text: str
    content_hash: str
    node_type: str
    page_number: int | None

class SelectionCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    node_ids: list[str] = Field(min_length=1)
    version_id: int | None = None

class GenerateRequest(BaseModel):
    selection_id: str
    force_new: bool = False

class TestCase(BaseModel):
    title: str = Field(min_length=5, max_length=200)
    objective: str = Field(min_length=5)
    preconditions: list[str] = []
    steps: list[str] = Field(min_length=1)
    expected_result: str = Field(min_length=5)
    requirement_trace: list[str] = Field(min_length=1)
    risk: str = "medium"

class GenerationOut(BaseModel):
    generation_id: str
    selection_id: str
    provider: str
    status: str
    stale: bool
    stale_reasons: list[str]
    test_cases: list[TestCase]
    warnings: list[str] = []
