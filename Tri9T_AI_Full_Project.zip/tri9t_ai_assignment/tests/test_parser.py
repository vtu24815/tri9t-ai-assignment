from app.parser import _heading_level, normalize, sha256_text

def test_duplicate_heading_text_is_not_a_global_identity():
    # The API's logical key incorporates the full parent path; same heading under
    # different parents therefore remains distinct (verified here at key primitive level).
    from app.main import _logical_key
    a = _logical_key(["Safety"], "Warnings", "A")
    b = _logical_key(["Maintenance"], "Warnings", "B")
    assert a != b

def test_numbered_heading_levels():
    assert _heading_level("1 Introduction") == 1
    assert _heading_level("2.3 Measurement Procedure") == 2
    assert _heading_level("2.3.1 Cuff Setup") == 3

def test_normalization_makes_hash_whitespace_stable():
    assert sha256_text(normalize("hello   world")) == sha256_text(normalize("hello\nworld"))

def test_parser_warns_for_empty_scanned_page(tmp_path):
    # A valid one-page PDF with no text simulates a scanned/image-only page.
    import fitz
    from app.parser import parse_pdf
    path = tmp_path / "empty.pdf"
    doc = fitz.open()
    doc.new_page()
    doc.save(path)
    doc.close()
    nodes, warnings = parse_pdf(str(path))
    assert nodes == []
    assert any("OCR is not configured" in w for w in warnings)
