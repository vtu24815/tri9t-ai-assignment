# Approach Document — Tri9T AI CT-200 QA Traceability API

## 1. Overview
This backend turns a CT-200 PDF manual into a versioned hierarchy, allows version-pinned selections, generates 3–5 QA test ideas, and exposes retrieval-time staleness status.

## 2. Parsing approach
PyMuPDF extracts text spans, line text, font sizes, and page numbers. Explicit numbered headings take priority; capitalization/title case and relative font size are fallback signals. A heading stack reconstructs hierarchy. Non-heading lines are appended to the current section body. Page-number-only lines are ignored. Pages without extractable text produce warnings.

This is a targeted parser, not a universal PDF parser. The actual CT-200 manuals must be visually inspected before claiming full coverage. Tables, figures, captions, multi-column layout, and scanned pages are known risks; OCR and layout-specific logic should be added from observed examples.

## 3. Data model
- `Document`: logical document identity.
- `DocumentVersion`: immutable ingestion metadata, sequence number, source filename and source SHA-256.
- `DocumentNode`: one node per version, heading, hierarchy level, body, parent, content hash, logical key, type and page.
- `Selection` / `SelectionItem`: named selection plus exact version, node hash and text snapshot.
- `GenerationRecord`: relational metadata and source manifest.
- JSON store: generated test-case payloads, kept separately from relational metadata.

## 4. Version matching
Logical key = SHA-256 of normalized ancestor heading path plus normalized heading. This preserves same-titled sections under different parents and permits stable IDs across versions when path/title remain unchanged. Content hash covers normalized heading and body. Changed body under a matching key is marked changed.

Failure modes: renamed/moved headings, same-title siblings under one parent, parser segmentation changes, and semantically equivalent wording can produce unmatched keys. The API reports unmatched nodes as removed/moved/unmatched; it does not claim semantic equivalence.

## 5. API design
- Ingest: `POST /documents/ingest`
- Root sections: `GET /documents/{name}/sections`
- Node tree: `GET /nodes/{id}`
- Search: `GET /search`
- Change check: `GET /nodes/{id}/changes`
- Create/retrieve selection: `POST /selections`, `GET /selections/{id}`
- Generate: `POST /generate`
- Retrieve generated output and current staleness: `GET /generations/{id}` and filtered `GET /generations`

## 6. LLM prompt and resilience
The prompt restricts generation to supplied source text, requires 3–5 test cases, defined fields, exact heading traceability, and JSON-only output. Responses are parsed and validated with Pydantic. A malformed response, HTTP failure, invalid count, or invalid field triggers one retry; after failure, deterministic local examples are returned with warnings. Without configuration, fallback mode is explicit in response metadata. The fallback exists to make local setup and API demonstrations possible; it should not be presented as actual LLM output.

Repeated submission policy: by default, reuse the most recent generation for the same selection to avoid duplicate calls and costs. `force_new=true` explicitly requests a new generation.

## 7. Staleness / impact detection
Each generation stores a source manifest with node ID, version ID, logical key, heading and content hash. At retrieval time, the manifest is matched against the latest version. Missing or changed nodes make the generation stale. This is conservative and syntactic: punctuation edits and clinically significant threshold changes both trigger review. It does not auto-regenerate cases or determine clinical significance.

## 8. Validation and test strategy
Included unit tests check:
1. duplicate headings under different parents yield different logical keys;
2. numbered heading levels are reconstructed;
3. whitespace-only changes normalize to the same hash;
4. image-only pages produce an explicit warning.

After the actual manuals are available, inspect all pages and create fixture-based regression tests for each observed irregularity, including duplicate headings, inconsistent numbering, tables, captions, page breaks, and any heading/body ambiguity. Verify v1→v2 changes through API calls and assert generation retrieval reports staleness.

## 9. Decision log
1. **Most likely silent error:** body text misclassified as heading due to font cues. Catch it with visual side-by-side comparison, snapshots, and tests built from actual irregular pages.
2. **Simplicity over correctness:** path/title matching is used rather than a semantic matcher plus human review. Renamed or moved content can be treated as unmatched; a production workflow should offer match candidates and review.
3. **Unsupported input:** scanned/image-only pages are skipped with a warning because OCR is not wired in. This is visible failure rather than silent data loss; add OCR with confidence thresholds and manual review.

## 10. Known limitations and next steps
- No authentication, intentionally out of scope.
- SQLite and a local JSON file are suitable for assignment/demo use, not concurrent multi-instance production.
- Parent-child identity across versions requires careful regression testing.
- Add OCR, table/caption extraction, and actual-manual fixtures.
- Add a semantic-diff layer that flags changed numbers, units, thresholds, and modal terms for risk-based triage while still requiring human review.
