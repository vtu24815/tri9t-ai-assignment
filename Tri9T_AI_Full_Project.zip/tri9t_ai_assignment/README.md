# Tri9T AI — CT-200 QA Traceability API

A focused backend implementation for the Tri9T AI Engineering Internship assignment. It parses PDF text into a hierarchy, stores immutable document versions, creates version-pinned selections, generates structured QA test ideas, and reports whether their source sections changed.

> **Important limitations:** The assignment PDF was available, but `ct200_manual.pdf` and `ct200_manual_v2.pdf` were not provided in the conversation. Do not claim the parser has been validated against those real manuals until you ingest and inspect them. PyMuPDF text extraction is implemented; image-only pages are explicitly warned about rather than silently treated as parsed. OCR/Tesseract wiring and layout-aware table extraction are future improvements.

## Stack

- FastAPI + Pydantic
- SQLAlchemy + SQLite
- PyMuPDF for PDF text and font/layout cues
- JSON file store for generated output (atomic file replacement)
- Optional OpenAI-compatible chat-completions endpoint
- pytest

## Setup

Python 3.11+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` for Swagger UI.

## Configure an LLM (optional)

The API works without an external provider using deterministic local fallback test ideas. For a real OpenAI-compatible endpoint, edit `.env`:

```dotenv
LLM_PROVIDER=openai-compatible
LLM_API_KEY=your_key
LLM_MODEL=your_model
LLM_BASE_URL=https://your-provider.example/v1
```

Do not commit `.env` or API keys. The code validates JSON output with Pydantic, requires 3–5 test cases, retries once, then falls back with explicit warnings.

## Ingest the manual

```bash
curl -X POST "http://127.0.0.1:8000/documents/ingest?document_name=CT-200" \
  -F "file=@data/ct200_manual.pdf"
```

Ingest v2 under the same `document_name`:

```bash
curl -X POST "http://127.0.0.1:8000/documents/ingest?document_name=CT-200" \
  -F "file=@data/ct200_manual_v2.pdf"
```

Identical file bytes are idempotent: ingesting the same PDF again returns its existing version. Different bytes create the next version.

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/documents/ingest?document_name=CT-200` | Ingest a PDF |
| GET | `/documents` | List documents and latest version |
| GET | `/documents/CT-200/sections?version=1` | List root sections |
| GET | `/nodes/{node_id}?version_id=1` | Get node and descendants |
| GET | `/search?q=pressure&document_name=CT-200` | Search headings/body |
| GET | `/nodes/{node_id}/changes` | Compare node with latest version |
| POST | `/selections` | Create version-pinned selection |
| GET | `/selections/{selection_id}` | Retrieve selection snapshots |
| POST | `/generate` | Generate QA cases from a selection |
| GET | `/generations/{generation_id}` | Retrieve output + live staleness |
| GET | `/generations?selection_id=...` | Retrieve by selection |
| GET | `/generations?node_id=...` | Retrieve generations referencing a node |

## End-to-end demonstration

1. Start the server and ingest v1.
2. List sections and choose a node ID from the response.
3. Create a selection (use node ID; optionally pass its `version_id`):

```json
{"name":"Safety test ideas","node_ids":["PASTE_NODE_ID"],"version_id":1}
```

4. Generate:

```json
{"selection_id":"PASTE_SELECTION_ID"}
```

5. Ingest v2. Retrieve the generation again. The response computes staleness against the latest version.
6. Compare a node with `/nodes/{node_id}/changes`.

The JSON generation payload is stored separately in `generated/test_cases.json`; relational metadata and source manifests are in SQLite. Old selection snapshots remain resolvable after re-ingestion.

## Version matching and known limits

A logical node key hashes its normalized heading plus ancestor heading path. This avoids merging duplicate headings under different parents. Nodes with the same key reuse the prior version's logical node ID; each version has its own row for that ID. Body content hashes detect changed text. The path/title strategy can fail when headings are renamed, moved, duplicated under the same parent, or when parser boundaries shift. Such cases should be manually reviewed rather than interpreted as guaranteed semantic equivalence.

Staleness is conservative: any changed source-node hash or unmatched logical key marks the generation stale. It does not understand semantic severity; a harmless punctuation edit and a changed clinical threshold both mark stale. This intentionally favors review over silently declaring potentially unsafe tests current.

## Parser strategy and edge cases

- Prefer explicit numbered heading patterns; use font size/case as a fallback.
- Maintain a heading stack to reconstruct parent-child relationships.
- Preserve repeated headings as separate rows; identity includes parent path.
- Ignore page-number-only lines.
- Warn on pages with no extractable text.
- Tables, figures/captions, multi-column layouts, and irregular numbering need manual visual comparison and additional targeted parser tests for the actual CT-200 manuals. Current extraction does not guarantee table-cell reconstruction or figure understanding.

## Decision log

1. **Most likely silent error:** a body line may be misclassified as a heading due to typography. Catch it with page-by-page visual comparison, extracted-node snapshots, heading-count assertions, and targeted fixtures from irregular pages.
2. **Simplicity over correctness:** path/title matching is used instead of semantic embeddings and human-approved mappings. Renamed or moved sections can appear removed/new; production should support candidate matches and manual review.
3. **Unsupported input:** image-only PDF pages are not OCR'd by this version. It emits a warning and skips the page rather than inventing content; add OCR and verify OCR confidence before production use.

## Testing

```bash
pytest -q
```

Tests cover numbered heading levels, duplicate heading identity across different parent paths, whitespace normalization, and warning behavior for image-only pages. Add fixture-based tests for each irregularity found in the real CT-200 manuals.

## Git history

Use incremental commits (do not squash everything into a single initial commit):

```bash
git init
git add requirements.txt .gitignore .env.example
git commit -m "chore: initialize FastAPI project configuration"
git add app/database.py app/models.py app/schemas.py
git commit -m "feat: define versioned document and selection models"
git add app/parser.py tests/test_parser.py
git commit -m "feat: parse PDF text and reconstruct section hierarchy"
git add app/main.py
git commit -m "feat: add ingestion browse search and selection APIs"
git add app/generator.py app/store.py
git commit -m "feat: generate validated QA cases and track staleness"
git add README.md
git commit -m "docs: document setup decisions and end-to-end flow"
```

## Submission checklist

- [ ] Ingest and inspect both real CT-200 PDFs.
- [ ] Add tests for all irregularities listed in the actual manual.
- [ ] Run tests and the full v1 → v2 → stale retrieval flow.
- [ ] Configure a real LLM provider if required and test malformed responses.
- [ ] Push repository to GitHub.
- [ ] Include repository and Approach Document links in submission email.
